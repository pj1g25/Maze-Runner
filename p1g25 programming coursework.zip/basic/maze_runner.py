from maze import *
from runner import *
import argparse
import csv

def shortest_path(maze_file, maze, starting: tuple[int, int] =None, goal: tuple[int, int]=None) -> list[tuple[int, int, str]]:
    #first the function creates the default starting and goal coordinates
    try:
    
        if starting == None:
            starting = (0,0)
        else:
            #checking the starting coordinates are in bounds
            if not check_starting(maze, starting):
                raise ValueError("Starting coordinates are not in range of the maze.")
        if goal == None:
            dimensions = get_dimensions(maze)
            goal = (dimensions[0]-1, dimensions[1]-1)
        else:
            #checking the goall coordinates are in bounds
            if not check_goal(maze, goal):
                raise ValueError("Goal coordinates are not in range of the maze.")
        if starting == goal:
            raise ValueError("Starting and goal coordinates cannot be the same.")

        #next the function creates the runner at the starting point and the runner explores the maze
        myrunner = create_runner(starting[0], starting[1], "N")
        explored_path = explore(myrunner, maze, goal)
        #the path with minimum steps will start at the starting coordinates
        min_path =[]
        #this for loop iterates through all the elements in the explored path
        #anytime it finds that a coordinate has been repeated, it goes to the last time that coordinate was recorded and removes all elements after that coordinate
        for step in explored_path:
            repeated_coord = False
            coordinate_x = step[0]
            coordinate_y = step[1]
            #this for loop finds compares all the coordinates recorded so far to the current one
            for i in range(0, len(min_path)):
                if  coordinate_x == min_path[i][0] and coordinate_y == min_path[i][1]:
                    repeated_coord = True
            #this if statement adds the new step if the coordinate was not found in the minimum path already
            if not repeated_coord:
                min_path.append(step)
            else:
                #if the coordinate was found the while loop removes every element in the minimum path list starting from the end and moving backwards
                #until it reaches the first time that coordinate was recorded
                repeated_coord_reached = False
                index=len(min_path)-1
                while not repeated_coord_reached:
                    coords = (min_path[index][0], min_path[index][1])
                    if coords == (coordinate_x, coordinate_y):
                        repeated_coord_reached = True
                    else:
                        min_path.remove(min_path[index])
                    index -=1
        record_exploration(explored_path)
        statistics_file(maze_file, explored_path, min_path)
        print(min_path)
    except ValueError as e:
        print(f"Error: {e}")
        min_path = None
    return min_path

def record_exploration(explored_path: list[tuple[int, int, str]]) -> None:
    #this function creates and writes to the exploration file
    with open('exploration.csv', 'w', newline = '') as file:
        writer = csv.writer(file)
        writer.writerow(['Step', 'x-coordinate', 'y-coordinate', 'Actions'])
        for i in range(0, len(explored_path)-1):
            writer.writerow([i+1, explored_path[i][0], explored_path[i][1], explored_path[i][2]])

def statistics_file(maze_file: str, exploration_path: list[tuple[int, int, str]], final_path:list[tuple[int, int, str]]) -> None:
    #this function creates and writes to a statistics.txt file
    with open('statistics.txt', 'w') as file:
        file.write(maze_file)
        exploration_steps = len(exploration_path)
        path_length = len(final_path)
        score = exploration_steps/(4+path_length)
        file.write(str(score)+"\n")
        file.write(str(exploration_steps)+"\n")
        path_string ="["
        for i in range(0, path_length):
            path_string = path_string + (f"({final_path[i][0]},{final_path[i][1]})")
            if i != path_length-1:
                path_string = path_string +", "
        path_string = path_string + "]"  
        file.write(path_string+"\n")
        file.write(str(path_length))

def check_starting(maze: dict, starting: tuple[int, int]) -> bool:
    #this function checks that the starting coordinates are inside the maze
    dimensions = get_dimensions(maze)
    width = dimensions[0]-1
    height = dimensions[1]-1

    if starting[0] <0 or starting[0] > width:
        return False
    elif starting[1]<0 or starting[1]>height:
        return False
    return True

def check_goal(maze:dict, goal: tuple[int, int]) -> bool:
    #this function checks that the goal coordinates are inside the maze
    dimensions = get_dimensions(maze)
    width = dimensions[0]-1
    height = dimensions[1]-1

    if goal[0] <0 or goal[0] > width:
        return False
    elif goal[1]<0 or goal[1]>height:
        return False
    return True

def check_dimensions(maze:list) -> bool:
    #this function makes sure the entire maze is a rectangle with no missing elements
    first_line = len(maze[0])
    #it iterates through each line making sure they are all the sane length
    for line in maze:
        if len(line) != first_line:
            return False
    return True

def check_outer_walls(maze:list) -> bool:
    #this function checks all the elements on the egdes of the maze to check they are all '#'s
    for i in range(0, len(maze)):
        row = list(maze[i])
        for j in range(0, len(row)):
            if i == 0 or i == len(maze) - 1:
                if row[j] != "#":
                    return False
            if j == 0 or j == len(row) - 1:
                if row[j] != "#":
                    return False
    return True

def check_elements(maze:list) -> bool:
    #this function checks that every element in the maze is eiher a '.' or '#'
    for i in range(0, len(maze)):
        row = list(maze[i])
        for j in range(0, len(row)):
            if row[j] != "#" and row[j] != ".":
                return False
    return True

def check_vertical_walls(maze:list) -> bool:
    #this checks every space where there should not be a wall and returns false is any of them are not a '.'
    for i in range(1, len(maze)-1, 2):
        row = list(maze[i])
        for j in range(1, len(row)-1, 2):
            if row[j] != ".":
                return False
    return True

def check_horizontal_walls(maze:list) -> bool:
    #this checks every space there should be a '#' and returns false is there isnt
    for i in range(2, len(maze)-1 ,2):
        row = list(maze[i])
        for j in range(2, len(row)-1, 2):
            if row[j] != '#':
                return False
    return True


def maze_reader(maze_file: str):
    try:

        with open(maze_file, "r") as file:
            #this part reads the maze and removes all the new lines
            maze =[]
            file_maze = file.readlines()
            height = int((len(file_maze)-1)/2)
            for i in range(0, len(file_maze)):
                row = list(file_maze[i])
                if row[-1] == "\n":
                    row.remove("\n")
                width = int((len(row)-1)/2)
                maze.append(row)
            #first validate the maze
            #checking the maze is a rectangle
            if not check_dimensions(maze):
                raise ValueError("incorrect dimensions")
            #checking the outer walls
            if not check_outer_walls(maze):
                raise ValueError("outer walls are not complete")
            #checking the are no illegal characters in the maze
            if not check_elements(maze):
                raise ValueError("not all elements in the maze are valid")
            #checking the vertical walls
            if not check_vertical_walls(maze):
                raise ValueError("not all vertical walls are valid")
            if not check_horizontal_walls(maze):
                raise ValueError("not all horizontal walls are valid")
            
            dict_maze = create_maze(width, height)
            #vertical walls
            #the for loop iterates through every other row of the maze starting with the second row
            for i in range(1, len(maze)-1, 2):
                row = list(maze[i])
                #this for loop iterates through every other element starting with the third one
                #this makes the code look at every possible coordinate there might be a vertical wall
                for j in range(2, len(row)-1, 2):
                    #whenever a vertical wall is present, a vetical wall is added at that position in the dictionary
                    if row[j] == '#':
                        #the rows that the vertical line appear in are the odd indexes (1, 3, 5...)
                        #firstly ((i-2)/2)-1 finds which odd number row the wall is at (0th, 1st, 2nd..)
                        #then because the rows start from 0 at the top of the maze, the value is subtracted from the height of maze
                        y_coord = height -int((i-1)/2)-1
                        #every column number with an even index is where a vertical wall might be
                        #therefore the index is divided by 2
                        vertical_line = int(j/2)
                        dict_maze =add_vertical_wall(dict_maze, y_coord, vertical_line)
            #horizontal walls
            #this loop iterates through every other row in the maze, starting with the third row
            for i in range(2, len(maze)-1, 2):
                row = list(maze[i])
                #this loop iterates through every other element in the row starting with the second one
                #this makes the code look at every possible position a wall could appear
                for j in range(1, len(row)-1, 2):
                    if row[j] == '#':
                        #this finds which odd numbered row the wall is at (0th, 1st, 2nd...), thats its x coordinate
                        x_coord = int((j-1)/2)
                        #the horizontal walls are on every row with an even index so to find which ro, the code divides the index by 2
                        #then the value is subtracted from the height of the mae so that y coordinate 0 is at the bottom row not top
                        horizontal_line = height -int(i/2)
                        dict_maze =add_horizontal_wall(dict_maze, x_coord, horizontal_line)
    #handle all the errors if they are raised
    except IOError:
        raise IOError("Unable to read from file.")
    except PermissionError:
        raise PermissionError("Do not have permission to read from file.")
    except ValueError as e:
        print(f"Maze format error: {e}")
        dict_maze = None
    except FileNotFoundError:
        raise FileNotFoundError("File given was not found.")
    return dict_maze

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        prog = "ECS Maze Runner",
        description = "ECS Maze Runner"
    )
    parser.add_argument("--starting", help= 'The starting position, e.g., "2, 1"')
    parser.add_argument("--goal", help = 'The goal position, e.g., "4, 5"')
    parser.add_argument("maze", help = 'The name of the maze file, e.g., maze1.mz')

    args = parser.parse_args()

    #turning the string input into a tuple
    try:
        
        error = False
        if args.starting != None:
            starting_list = args.starting.split(',')
            starting_tuple = (int(starting_list[0]), int(starting_list[1]))
        else:
            starting_tuple = None

        if args.goal != None:
            goal_list = args.goal.split(',')
            goal_tuple = (int(goal_list[0]), int(goal_list[1]))
        else:
            goal_tuple = None
    except ValueError as e:
        print("Error: incorrect format of coordinates")
        starting_tuple = None
        goal_tuple = None
        error = True

    dict_maze =maze_reader(args.maze)
    if dict_maze == None:
        error = True
    if not error :
        shortest_path(args.maze, dict_maze, starting_tuple, goal_tuple)

