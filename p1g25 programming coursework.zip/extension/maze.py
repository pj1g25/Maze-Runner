def create_maze(width:int = 5, height:int = 5) -> list[list[dict[str:bool]]]:
    #the maze is a 2D list with the second dimension of lists containing dictionaries
    #the 2D list is representative of the grid that the maze is made of
    #the dictionaries contain information on the presence of a wall on the north and east sides of the box (there will be extra walls on three of the corners)
    #a coordinate will represent the bottom left corner of a box
    maze = []
    row = []
    #this loop creates an empty maze with no walls at all
    for i in range(0, height+1):
    #there must be one more row of boxes at the bottom of the maze that are 'invisible' in order to create the bottom wall
        for j in range(0, width+1):
        #there must be one more column of boxes on the left of the maze to create the left wall of the maze
            row.append({'wallH':False, 'wallV':False})
        maze.append(row)
        row=[]
    #this for loop adds the edge walls of the maze
    for i in range(0, len(maze)):
        cell = maze[i]
        for j in range(0, width+1):
            if i == 0 or i == height:
                cell[j]['wallH'] = True
                #True indicates there is a wall on the north side of that box
            if j == 0 or j == width:
                cell[j]['wallV'] = True
                #True indicates there is a wall on the east side of that box
    return maze

def add_horizontal_wall(maze:list, x_coordinate:int, horizontal_line:int) -> list:
    #the y coordinates start from the bottom of the maze but the list's 0 index is at the top
    #this line takes the y coordinate given and gives the equivalent row in the list
    horizontal_line = len(maze)-horizontal_line-1
    row = maze[horizontal_line]
    row[x_coordinate+1]['wallH'] = True
    #this finds the correct dictionary and modifies it
    #the x coordinate must be incremented by one because the maze has one extra column of boxes on the left
    return maze

def add_vertical_wall(maze:list, y_coordinate:int, vertical_line:int) -> list:
    #this function finds the row that the y coordinate corresponds to, then the dictionary that will contain the correct vertical line
    #the y_coordinate must be incremented by one because where the 2D list's (1,1) coordinates are the maze's (0,0) coordinates
    y_coordinate += 1
    y_coordinate = len(maze)-y_coordinate-1
    row = maze[y_coordinate]
    row[vertical_line]['wallV'] = True
    return maze

def get_dimensions(maze) -> tuple[int, int]:
    #the height and width need to be decremented by one because the maze has a row and column of unused boxes
    height = len(maze)-1
    width = len(maze[0])-1
    return (width, height)

def get_walls(maze, x_coordinate: int, y_coordinate: int) -> tuple[bool, bool, bool, bool]:
    #1 is added to the x and y coordinates because of the unused row and column
    y_coordinate = y_coordinate + 1
    x_coordinate = x_coordinate + 1
    #correcting the y coordinate because the highest index is at the bottom of the maze
    y_coordinate = len(maze) -1- y_coordinate
    row = maze[y_coordinate]
    #information on the north and east walls are already in the dictionary of the box
    north = row[x_coordinate]['wallH']
    east = row[x_coordinate]['wallV']
    #the west wall is found by looking at the east wall of the box on the left of the current one
    west = row[x_coordinate-1]['wallV']
    #the south wall is found by looking at the north wall of the box under the current one
    row = maze[y_coordinate+1]
    south = row[x_coordinate]['wallH']
    return (north, east, south, west)




