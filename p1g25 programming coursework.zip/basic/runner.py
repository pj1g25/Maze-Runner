from maze import *

def create_runner(x:int =0, y:int =0, orientation: str="N") -> dict:
    runner = {'x':x, 'y':y, 'orientation':orientation}
    #the runner's data type is a dictionary because the values can be changed and it is obvious what value you are retrieving
    return runner

def get_x(runner:dict) -> int:
    return runner['x']
def get_y(runner:dict) -> int:
    return runner['y']
def get_orientation(runner:dict) -> str:
    return runner['orientation']

def turn(runner:dict, direction: str) -> dict:
    if direction == "Left":
        #turning in an anti-clockwise direction
        if get_orientation(runner) == "N":
            runner['orientation'] = "W"
        elif get_orientation(runner) == "E":
            runner['orientation'] = "N"
        elif get_orientation(runner) == "S":
            runner['orientation'] = "E"
        elif get_orientation(runner) == "W":
            runner['orientation'] = "S"
    if direction == "Right":
        #turning in a clockwise direction
        if get_orientation(runner) == "N":
            runner['orientation'] = "E"
        elif get_orientation(runner) == "E":
            runner['orientation'] = "S"
        elif get_orientation(runner) == "S":
            runner['orientation'] = "W"
        elif get_orientation(runner) == "W":
            runner['orientation'] = "N"
    return runner
def forward(runner: dict) -> dict:
    if get_orientation(runner) == "N":
        runner['y']+=1
        #runner moves up
    elif get_orientation(runner) == "S":
        runner['y']-=1
        #runner moves down
    elif get_orientation(runner) == "E":
        runner['x']+=1
        #runner moves to the right
    elif get_orientation(runner) == "W":
        runner['x']-=1
        #runner moves to the left
    return runner

def sense_walls(runner: dict, maze: list) -> tuple[bool, bool, bool]:
    #first I fetch all the variables for the functions
    x= get_x(runner)
    y= get_y(runner)
    orientation = get_orientation(runner)
    walls = get_walls(maze, x, y)
    #these if statements check the orientation of the runner
    #then the correct walls are taken from the tuple depending on what to the left, right or in front of the runner
    if orientation =="N":
        walls = (walls[3], walls[0], walls[1])
    elif orientation =="E":
        walls = (walls[0], walls[1], walls[2])
    elif orientation =="S":
        walls = (walls[1], walls[2], walls[3])
    elif orientation =="W":
        walls = (walls[2], walls[3], walls[0])
    return walls

def go_straight(runner: dict, maze: list) -> dict:
    #fetches the wall the runner is facing
    wall_in_front = sense_walls(runner, maze)[1]
    try:
        if wall_in_front:
            #if the runner is facing a wall then the ValueError is raised
            raise ValueError('wall in the way')
        else:
            #update the runner's coordinates if there is no wall
            runner = forward(runner)
    except ValueError as e:
        print(f"Error: {e}")
    return runner

def move(runner: dict, maze: list) -> tuple[dict, str]:
    #this function compares the correct wall to the direction that the runner is trying to move in
    #if there is a wall present, it moves on the next direction in the order of left, forward, right and backwards
    walls = sense_walls(runner, maze)
    moves = ""
    if not walls[0]:
        runner =turn(runner, "Left")
        runner = go_straight(runner, maze)
        moves= moves+"LF"
    elif not walls[1]:
        runner = go_straight(runner, maze)
        moves = moves+"F"
    elif not walls[2]:
        runner = turn(runner, "Right")
        runner = go_straight(runner, maze)
        moves = moves+"RF"
    else:
        runner = turn(runner, "Right")
        runner = turn(runner, "Right")
        runner = go_straight(runner, maze)
        moves = moves+"B"
    return (runner, moves)

def explore(runner: dict, maze: list, goal : tuple[int, int] = None) -> list[tuple[int, int, str]]:
    #if there is no goal the coordinates of the top right corner box are fetched
    if goal == None:
        dimensions = get_dimensions(maze)
        goal = (dimensions[0]-1, dimensions[1]-1)
    current_position = (get_x(runner), get_y(runner))
    path = [(current_position[0], current_position[1], 'F')]
    #the runner will make moves until its position is the same as the goal
    while current_position != goal:
        runner_moves =move(runner, maze)
        moves = runner_moves[1]
        runner = runner_moves[0]
        current_position = (get_x(runner), get_y(runner))
        #every move, the move just made and the runner's position are added to the final list that will be returned
        path.append((get_x(runner), get_y(runner), moves))
    return path


