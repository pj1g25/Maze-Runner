from maze import *

def create_runner(x:int =0, y:int =0, orientation: str="N") -> dict:
    runner = {'x':x, 'y':y, 'orientation':orientation}
    #the runner's data type is a dictionary because the values can be changed and it is obvious what value you are retrieving
    return runner

def get_x(runner:dict) -> int:
    return runner['x']
def get_y(runner:dict) -> int:
    return runner['y']
def get_orientation(runner:dict) -> str:
    return runner['orientation']

def turn(runner:dict, direction: str) -> dict:
    if direction == "Left":
        #turning in an anti-clockwise direction
        if get_orientation(runner) == "N":
            runner['orientation'] = "W"
        elif get_orientation(runner) == "E":
            runner['orientation'] = "N"
        elif get_orientation(runner) == "S":
            runner['orientation'] = "E"
        elif get_orientation(runner) == "W":
            runner['orientation'] = "S"
    if direction == "Right":
        #turning in a clockwise direction
        if get_orientation(runner) == "N":
            runner['orientation'] = "E"
        elif get_orientation(runner) == "E":
            runner['orientation'] = "S"
        elif get_orientation(runner) == "S":
            runner['orientation'] = "W"
        elif get_orientation(runner) == "W":
            runner['orientation'] = "N"
    return runner

def forward(runner: dict) -> dict:
    if get_orientation(runner) == "N":
        runner['y']+=1
        #runner moves up
    elif get_orientation(runner) == "S":
        runner['y']-=1
        #runner moves down
    elif get_orientation(runner) == "E":
        runner['x']+=1
        #runner moves to the right
    elif get_orientation(runner) == "W":
        runner['x']-=1
        #runner moves to the left
    return runner

def sense_walls(runner: dict, maze: list) -> tuple[bool, bool, bool]:
    #first I fetch all the variables for the functions
    x= get_x(runner)
    y= get_y(runner)
    orientation = get_orientation(runner)
    walls = get_walls(maze, x, y)
    #these if statements check the orientation of the runner
    #then the correct walls are taken from the tuple depending on what to the left, right or in front of the runner
    if orientation =="N":
        walls = (walls[3], walls[0], walls[1])
    elif orientation =="E":
        walls = (walls[0], walls[1], walls[2])
    elif orientation =="S":
        walls = (walls[1], walls[2], walls[3])
    elif orientation =="W":
        walls = (walls[2], walls[3], walls[0])
    #walls tuple is returned as (left, forward, right)
    return walls

def go_straight(runner: dict, maze: list) -> dict:
    #fetches the wall the runner is facing
    wall_in_front = sense_walls(runner, maze)[1]
    try:
        if wall_in_front:
            #if the runner is facing a wall then the ValueError is raised
            raise ValueError('wall in the way')
        else:
            #update the runner's coordinates if there is no wall
            runner = forward(runner)
    except ValueError as e:
        print(f"Error: {e}")
    return runner

def move(runner: dict, maze: list) -> tuple[dict, str]:
    walls = sense_walls(runner, maze)
    moves = ""
    if not walls[0]:
        runner =turn(runner, "Left")
        runner = go_straight(runner, maze)
        moves= moves+"LF"
    elif not walls[1]:
        runner = go_straight(runner, maze)
        moves = moves+"F"
    elif not walls[2]:
        runner = turn(runner, "Right")
        runner = go_straight(runner, maze)
        moves = moves+"RF"
    else:
        runner = turn(runner, "Right")
        runner = turn(runner, "Right")
        runner = go_straight(runner, maze)
        moves = moves+"B"
    return (runner, moves)


def turn_back(runner, maze):
    #this function makes the runner turn back to the space behind it and then face that same direction again
    runner = turn(runner, 'Right')
    runner = turn(runner, 'Right')
    runner = go_straight(runner, maze)
    runner = turn(runner, 'Left')
    runner = turn(runner, 'Left')
    return runner


def explore(runner: dict, maze: list, goal : tuple[int, int] = None) -> list[dict[tuple[int, int], int, str]]:
    #making the goal the top right corner if no goal is given
    if goal == None:
        dimensions = get_dimensions(maze)
        goal = (dimensions[0]-1, dimensions[1]-1)
    #this explore function creates a runner at the starting point, then everytime it finds a new direction it creates a new runner
    #that new runner visits the next coordinate and duplicates again in every direction it can
    #the old runner no longer exploring a new node is deleted but the coordinate it visited is stored
    #each coordinate visited is also given a number of coordinates that it took to get from the start to the goal
    #this is later used as a guide to find the shortest path from the goal to the start
    #the inital coordinates of the runner are stored in the visited list
    runnercoords = (get_x(runner), get_y(runner))
    visitednodes= [{'coords': runnercoords, 'distance': 0, 'move': 'F'}]
    #the first runner is stored
    runners = [runner]
    #the runners wil stop when the goal is found
    while runnercoords != goal:
        #every runner looks around them for new directions to run in
        for runner in runners:
            walls = sense_walls(runner, maze)
            runnercoords = (get_x(runner), get_y(runner))
            #find what the distance from the start is on the coordinate the runner is currently on
            for x in range(0, len(visitednodes)):
                if (visitednodes[x])['coords'] == runnercoords:
                    currentdistance = (visitednodes[x])['distance']
            #if theres no wall on the left, the runner checks what coordinate is on the left and creates a new runner there
            if not walls[0]:
                runner = turn(runner, 'Left')
                runner = go_straight(runner, maze)
                newrunnerleft =create_runner(get_x(runner), get_y(runner), get_orientation(runner))
                #the runner needs to go back to its original position in case there are more directions to explore
                runner = turn_back(runner, maze)
                runner = turn(runner, 'Right')
                coords = (get_x(newrunnerleft), get_y(newrunnerleft))
                #the coordinate on the left is added to the visited nodes list with an updated distance value
                visitednodes.append({'coords':coords, 'distance' : currentdistance +1, 'move' : 'LF'})
                #the new runner is added to the list
                runners.append(newrunnerleft)
            #same routine if there is no wall in front
            if not walls[1]:
                runner = go_straight(runner, maze)
                newrunnerforward = create_runner(get_x(runner), get_y(runner), get_orientation(runner))
                runner = turn_back(runner, maze)
                coords = (get_x(newrunnerforward), get_y(newrunnerforward))
                visitednodes.append({'coords': coords, 'distance': currentdistance +1, 'move': 'F'})
                runners.append(newrunnerforward)
            #same routine again if there is no wall on the right
            if not walls[2]:
                runner = turn(runner, 'Right')
                runner = go_straight(runner, maze)
                newrunnerright = create_runner(get_x(runner), get_y(runner), get_orientation(runner))
                runner = turn_back(runner, maze)
                runner = turn(runner, 'Left')
                coords = (get_x(newrunnerright), get_y(newrunnerright))
                visitednodes.append({'coords': coords, 'distance': currentdistance +1, 'move': 'RF'})
                runners.append(newrunnerright)
            
            #the runner that just explored all the possible paths from the current coordinate is removed
            runners.remove(runner)
            if runnercoords == goal:
                #no more runners explore anymore once the goal coordinates have been reached
                break
    return visitednodes
